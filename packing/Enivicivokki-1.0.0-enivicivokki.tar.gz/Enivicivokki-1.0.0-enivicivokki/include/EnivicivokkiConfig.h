// the configured options and settings for Enivicivokki
#define Enivicivokki_VERSION_MAJOR 1
#define Enivicivokki_VERSION_MINOR 0
#define Enivicivokki_VERSION_MINOR 0


// the source code requires USE_MYMATH
#define USE_MYMATH 
